
import React from 'react'
import ReactDOM from 'react-dom/client'

function App(){
  return (
    <div style={{fontFamily:'Arial',maxWidth:'800px',margin:'0 auto',padding:'20px'}}>
      <h1>Fuerza Simple</h1>
      <p>Hola Silvina 👋</p>
      <div style={{border:'1px solid #ddd',padding:'16px',borderRadius:'12px'}}>
        <h2>Entrenamiento de hoy</h2>
        <ul>
          <li>Sentadilla Goblet</li>
          <li>Hip Thrust</li>
          <li>Peso Muerto Rumano</li>
          <li>Abducciones</li>
          <li>Plancha</li>
        </ul>
      </div>
    </div>
  )
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />)
